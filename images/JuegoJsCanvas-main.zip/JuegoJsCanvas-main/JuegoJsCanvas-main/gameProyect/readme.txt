=================================================================

    PROYECTO VIDEOJUEGO

=================================================================

//cuaderno De pitagora


Dia1:  Conseguir que la nave se mueva
Dia2: Crear los disparos y los obstaculos que se generen