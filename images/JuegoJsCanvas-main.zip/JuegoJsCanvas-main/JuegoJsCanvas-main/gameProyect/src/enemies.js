/*class Enemies {
    constructor(ctx, posY) {
        this.ctx = ctx,
            this.enemiesSpects = {
                pos: { x: posY, y: posY },
                size: { w: 200, y: 200 },
                speed: 10
            }
    }

    drawEnemies() {
        this.ctx.fillStyle = "Red"
        this.ctx.fillRect(this.enemiesSpects.pos.x, 600, 200, 200)
        this.move()
    }
    move() {
        this.enemiesSpects.pos.x -= this.enemiesSpects.speed
    }

}
*/