class Ship {
    constructor(ctx, posX, canvasSize) {
        this.ctx = ctx,
            this.canvasSize = canvasSize
        this.shipSpects = {
            pos: { x: posX, y: 800 },
            size: { w: 500, h: 500 },
            speed: 45
        },
            this.canLeft = false
        this.canRigth = false
        this.bullets = []    //creo una array de balas
        this.setEventListener()
    }



    //obetener los accionadores de teclado
    setEventListener() {
        document.onkeyup = event => {
            const { key } = event
            console.log(event)
            if (key == "ArrowLeft") {
                console.log("estoy aqui")
                this.shipSpects.pos.x -= this.shipSpects.speed
            }

            if (key == "ArrowRight") {
                this.shipSpects.pos.x += this.shipSpects.speed
            }

            if (key == "ArrowDown") {
                this.shipSpects.pos.y += this.shipSpects.speed

            }

            if (key == "ArrowUp") {
                this.shipSpects.pos.y -= this.shipSpects.speed
            }
            if (key == " ") {
                this.shoot()
            }
        }
    }
    drawShip() {
        console.log("me Dibujo")
        this.move()
        this.ctx.fillStyle = "Black"
        this.ctx.fillRect(this.shipSpects.pos.x, this.shipSpects.pos.y, 200, 200)
    }

    shoot() {
        //creo la función que activará el disparo
        console.log(this.bullets.length)
        this.bullets.push(new Bullets(this.ctx, this.shipSpects)) //para establecer los parámetros voy a necesitar el move() de la nave??
    }

    //con esta función move(), . Hago un for each para que "entre" dentro del array  la bala
    move() {

        this.bullets.forEach(bullet => bullet.drawBullets())
        this.clearBullets()
        /* this.canLeft ? this.shipSpects.pos.x -= 20 : this.shipSpects.pos.x
        this.canRigth ? this.shipSpects.pos.x += 20 : this.shipSpects.pos.x

 */    }

    clearBullets() {
        this.bullets = this.bullets.filter(e => e.bulletsSpects.pos.x < this.canvasSize.w)
        console.log(this.bullets.length)
    }


}